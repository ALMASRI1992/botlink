document.getElementById('applyButton').addEventListener('click', () => {
  fetch('http://127.0.0.1:5000/apply_jobs')
    .then(res => res.json())
    .then(data => {
      document.getElementById('status').textContent = data.message;
    })
    .catch(err => {
      document.getElementById('status').textContent = 'Erreur : ' + err;
    });
});